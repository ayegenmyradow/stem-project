const Config = {
    JWTSecretKey: "This is my secret key!",
    maxAge: 90 * 24 * 60
}
module.exports = Config;